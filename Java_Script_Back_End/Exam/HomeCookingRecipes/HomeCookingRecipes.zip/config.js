module.exports = {
    SECRET: 'asfasdf687asd8f76d79v6pnyerv!@#$',
};