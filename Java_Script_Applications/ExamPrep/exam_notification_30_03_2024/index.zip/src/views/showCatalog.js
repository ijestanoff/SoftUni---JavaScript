import { render } from '../lib.js';
import { getAllItems} from '../data/events.js';
import { html } from '../lib.js';

export async function showCatalog() {
    const items = await getAllItems();
    render(catalogTemplate(items));
}

const catalogTemplate = (items) =>html`
<h3 class="heading">Market</h3>
    <section id="dashboard">
        <!-- Display a div with information about every post (if any)-->
        ${items.length? items.map(itemTemplate) :null }
    </section>
    ${items.length? null : html`<h3 class="empty">No Items Yet</h3>` }
    `;

//item, imageUrl, price, availability, type, description
const itemTemplate = (item) =>html`
<div class="item">
    <img src=${item.imageUrl} alt="example1" />
    <h3 class="model">${item.item}</h3>
    <div class="item-info">
        <p class="price">Price: €${item.price}</p>
        <p class="availability">${item.availability}</p>
        <p class="type">Type: ${item.type}</p>
    </div>
    <a class="details-btn" href="/catalog/${item._id}">Uncover More</a>
    </div>`;

/*<h2>Fruits</h2>
<section id="dashboard">
    <!-- Display a div with information about every post (if any)-->
    ${items.length? items.map(itemTemplate) :null }
</section>
    <!-- Display an h2 if there are no posts -->
    ${items.length? null : html`<h2>No fruit info yet.</h2>` }*/

    
/*<div class="fruit">
    <img src=${item.imageUrl} alt="example1" />
    <h3 class="title">${item.name}</h3>
    <p class="description">${item.description}</p>
    <a class="details-btn" href="/catalog/${item._id}">More Info</a>
</div>*/
