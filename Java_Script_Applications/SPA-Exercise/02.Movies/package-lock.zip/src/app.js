import { visit } from './nav.js';

visit('Movies');
